# This file is imported from __init__.py and exec'd from setup.py

__version__ = "1.3.1"
